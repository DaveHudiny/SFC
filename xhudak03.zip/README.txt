Autor: David Hudák
Login: xhudak03
Téma projektu: Praktická klasifikační úloha s pomocí algoritmu backpropagation.

Pro spuštění projektu prosím použijte:
$ python3 main.py

Ve složce test a train se nachází ukázkový dataset pro xor problém pro inspiraci
při tvorbě vlastních datasetů a redukovaná verze MNIST datasetu (2400 trénovacích
a 1000 testovacích dat).

LaTeXová dokumentace k projektu se nachází ve výchozí složce pod názvem doc.pdf

Pro načtení nějaké již natrénované sítě můžete použít síť ve složce ./nnets/mnist1x128.pkl,
ale preferovanou variantu je vytvoření sítě vlastní (tato je pouze menší).

